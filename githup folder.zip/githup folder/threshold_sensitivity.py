
import pandas as pd
import numpy as np

# Load previous predictions
df = pd.read_csv(
    "outputs/prediction_audit/all_validation_predictions.csv"
)

y_true = df["actual_label"].to_numpy().astype(int)
y_prob = df["malignant_probability"].to_numpy()

thresholds = [0.05, 0.10, 0.15, 0.20, 0.25, 0.29018062, 0.35, 0.40, 0.50]

results = []

for threshold in thresholds:

    y_pred = (y_prob >= threshold).astype(int)

    tp = int(((y_true == 1) & (y_pred == 1)).sum())
    fn = int(((y_true == 1) & (y_pred == 0)).sum())
    fp = int(((y_true == 0) & (y_pred == 1)).sum())
    tn = int(((y_true == 0) & (y_pred == 0)).sum())

    precision = tp / (tp + fp) if tp + fp else 0
    recall = tp / (tp + fn) if tp + fn else 0
    specificity = tn / (tn + fp) if tn + fp else 0

    f1 = (
        2 * precision * recall / (precision + recall)
        if precision + recall else 0
    )

    results.append({
        "Threshold": threshold,
        "TP": tp,
        "FN": fn,
        "FP": fp,
        "TN": tn,
        "Precision": precision,
        "Recall": recall,
        "Specificity": specificity,
        "F1": f1
    })

results_df = pd.DataFrame(results)

print("\nTHRESHOLD SENSITIVITY ANALYSIS")
print("=" * 100)

print(
    results_df.round(4).to_string(index=False)
)

results_df.to_csv(
    "outputs/prediction_audit/threshold_sensitivity.csv",
    index=False
)

print("\nSaved: threshold_sensitivity.csv")
