
import torch
import torch.nn as nn
import torch.nn.functional as F


# ==========================================
# 1. WEIGHTED BCE LOSS
# ==========================================

def get_weighted_loss(train_dataset, device):

    labels = train_dataset.dataframe[
        "target"
    ].to_numpy(dtype=int)

    class_counts = torch.bincount(
        torch.tensor(labels, dtype=torch.long),
        minlength=2
    )

    negatives = class_counts[0].item()
    positives = class_counts[1].item()

    if positives == 0:
        raise ValueError(
            "No positive samples found in training dataset."
        )

    pos_weight_value = negatives / positives

    pos_weight = torch.tensor(
        [pos_weight_value],
        dtype=torch.float32,
        device=device
    )

    print("\nWEIGHTED BCE LOSS")
    print("-" * 40)
    print("Negative samples:", negatives)
    print("Positive samples:", positives)
    print("Positive weight:", pos_weight_value)

    criterion = nn.BCEWithLogitsLoss(
        pos_weight=pos_weight
    )

    return criterion


# ==========================================
# 2. WEIGHTED FOCAL LOSS
# ==========================================

class WeightedFocalLoss(nn.Module):

    def __init__(
        self,
        pos_weight,
        gamma=2.0
    ):

        super().__init__()

        self.register_buffer(
            "pos_weight",
            pos_weight.detach().clone()
        )

        self.gamma = gamma

    def forward(self, logits, targets):

        targets = targets.float()

        # Weighted BCE
        bce_loss = F.binary_cross_entropy_with_logits(
            logits,
            targets,
            pos_weight=self.pos_weight,
            reduction="none"
        )

        # Probability of the correct class
        probabilities = torch.sigmoid(logits)

        pt = (
            targets * probabilities
            + (1.0 - targets) * (1.0 - probabilities)
        )

        # Focal modulation
        focal_weight = (1.0 - pt).pow(self.gamma)

        focal_loss = focal_weight * bce_loss

        return focal_loss.mean()


# ==========================================
# 3. CREATE FOCAL LOSS
# ==========================================

def get_focal_loss(
    train_dataset,
    device,
    gamma=2.0
):

    labels = train_dataset.dataframe[
        "target"
    ].to_numpy(dtype=int)

    class_counts = torch.bincount(
        torch.tensor(labels, dtype=torch.long),
        minlength=2
    )

    negatives = class_counts[0].item()
    positives = class_counts[1].item()

    if positives == 0:
        raise ValueError(
            "No positive samples found in training dataset."
        )

    pos_weight_value = negatives / positives

    pos_weight = torch.tensor(
        [pos_weight_value],
        dtype=torch.float32,
        device=device
    )

    print("\nWEIGHTED FOCAL LOSS")
    print("-" * 40)

    print("Negative samples:", negatives)
    print("Positive samples:", positives)

    print(
        f"Positive weight: {pos_weight_value:.4f}"
    )

    print("Gamma:", gamma)

    criterion = WeightedFocalLoss(
        pos_weight=pos_weight,
        gamma=gamma
    ).to(device)

    return criterion
