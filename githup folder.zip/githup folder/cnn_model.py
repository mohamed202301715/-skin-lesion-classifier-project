"""
CNN (image-only) Skin Lesion Classifier
Train:
    python cnn_model.py --data "C:\\Users\\moham\\Downloads\\archive (3)" --exclude_labels unknown
Options:
    --backbone efficientnet_b0 | resnet50 | densenet121 | simple_cnn
    --csv / --img_col / --label_col   (if auto-detect picks the wrong ones)
    --min_class_count 50              (drop very rare classes)
    --exclude_labels unknown          (drop label values)
"""
import os
import json
import argparse
import random

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from PIL import Image
from torch.utils.data import Dataset, DataLoader
from torchvision import models, transforms
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, f1_score

try:
    from tqdm import tqdm
except ImportError:
    tqdm = lambda x, **k: x

IMG_EXT = (".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff")
LABEL_HINTS = ["diagnostic", "diagnosis", "dx", "label", "target", "class", "category", "lesion_type", "type"]
MEAN, STD = [0.485, 0.456, 0.406], [0.229, 0.224, 0.225]


# ----------------------------------------------------------------------------
# Transforms
# ----------------------------------------------------------------------------
def get_transforms(img_size=224, train=False):
    if train:
        return transforms.Compose([
            transforms.Resize((img_size + 32, img_size + 32)),
            transforms.RandomResizedCrop(img_size, scale=(0.7, 1.0)),
            transforms.RandomHorizontalFlip(),
            transforms.RandomVerticalFlip(),
            transforms.RandomRotation(30),
            transforms.ColorJitter(0.2, 0.2, 0.2, 0.02),
            transforms.ToTensor(),
            transforms.Normalize(MEAN, STD),
        ])
    return transforms.Compose([
        transforms.Resize((img_size, img_size)),
        transforms.ToTensor(),
        transforms.Normalize(MEAN, STD),
    ])


# ----------------------------------------------------------------------------
# Models
# ----------------------------------------------------------------------------
class SimpleCNN(nn.Module):
    """Plain CNN trained from scratch."""
    def __init__(self, num_classes, dropout=0.4):
        super().__init__()

        def block(i, o):
            return nn.Sequential(
                nn.Conv2d(i, o, 3, padding=1, bias=False), nn.BatchNorm2d(o), nn.ReLU(inplace=True),
                nn.Conv2d(o, o, 3, padding=1, bias=False), nn.BatchNorm2d(o), nn.ReLU(inplace=True),
                nn.MaxPool2d(2),
            )
        self.features = nn.Sequential(block(3, 32), block(32, 64), block(64, 128), block(128, 256), block(256, 512))
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.head = nn.Sequential(nn.Flatten(), nn.Dropout(dropout), nn.Linear(512, 256),
                                  nn.ReLU(inplace=True), nn.Dropout(dropout), nn.Linear(256, num_classes))

    def forward(self, x):
        return self.head(self.pool(self.features(x)))


def build_cnn(name, num_classes, pretrained=True, dropout=0.3):
    if name == "simple_cnn":
        return SimpleCNN(num_classes)
    try:
        if name == "efficientnet_b0":
            m = models.efficientnet_b0(weights=models.EfficientNet_B0_Weights.DEFAULT if pretrained else None)
            m.classifier = nn.Sequential(nn.Dropout(dropout), nn.Linear(m.classifier[1].in_features, num_classes))
        elif name == "resnet50":
            m = models.resnet50(weights=models.ResNet50_Weights.DEFAULT if pretrained else None)
            m.fc = nn.Sequential(nn.Dropout(dropout), nn.Linear(m.fc.in_features, num_classes))
        elif name == "densenet121":
            m = models.densenet121(weights=models.DenseNet121_Weights.DEFAULT if pretrained else None)
            m.classifier = nn.Sequential(nn.Dropout(dropout), nn.Linear(m.classifier.in_features, num_classes))
        else:
            raise ValueError(f"Unknown backbone {name}")
    except Exception as e:
        if not pretrained:
            raise
        print(f"[warn] could not load pretrained weights ({e}); using random init")
        return build_cnn(name, num_classes, pretrained=False, dropout=dropout)
    return m


def load_checkpoint(path, device):
    ck = torch.load(path, map_location=device, weights_only=False)
    model = build_cnn(ck["backbone"], len(ck["classes"]), pretrained=False)
    model.load_state_dict(ck["state"])
    return model.to(device).eval(), ck


# ----------------------------------------------------------------------------
# Data
# ----------------------------------------------------------------------------
class SkinDataset(Dataset):
    def __init__(self, paths, labels, tfm):
        self.paths, self.labels, self.tfm = paths, labels, tfm

    def __len__(self):
        return len(self.paths)

    def __getitem__(self, i):
        img = Image.open(self.paths[i]).convert("RGB")
        return self.tfm(img), torch.tensor(self.labels[i])


def index_images(root):
    by_name, by_stem = {}, {}
    for d, _, files in os.walk(root):
        for f in files:
            if f.lower().endswith(IMG_EXT):
                p = os.path.join(d, f)
                by_name[f.lower()] = p
                by_stem[os.path.splitext(f)[0].lower()] = p
    return by_name, by_stem


def resolve(v, by_name, by_stem):
    s = os.path.basename(str(v).replace("\\", "/")).lower()
    return by_name.get(s) or by_stem.get(os.path.splitext(s)[0])


def find_csv(root):
    csvs = [os.path.join(d, f) for d, _, fs in os.walk(root) for f in fs if f.lower().endswith(".csv")]
    if not csvs:
        raise FileNotFoundError("No CSV metadata file found in dataset folder.")
    train_csvs = [c for c in csvs if "train" in os.path.basename(c).lower()]
    return max(train_csvs or csvs, key=os.path.getsize)


def detect_columns(df, by_name, by_stem, img_col=None, label_col=None):
    if img_col is None:
        best, best_score = None, 0
        for c in df.columns:
            if df[c].dtype != object:
                continue
            sample = df[c].dropna().astype(str).head(50)
            if len(sample) == 0:
                continue
            score = np.mean([resolve(v, by_name, by_stem) is not None for v in sample])
            if score > best_score:
                best, best_score = c, score
        if best is None or best_score < 0.5:
            raise ValueError("Could not detect image column; pass --img_col")
        img_col = best
    if label_col is None:
        low = {c.lower(): c for c in df.columns}
        for h in LABEL_HINTS:
            if h in low and low[h] != img_col:
                label_col = low[h]
                break
        if label_col is None:
            cands = [c for c in df.columns if c != img_col and 1 < df[c].nunique() <= 30 and df[c].dtype == object]
            if not cands:
                raise ValueError("Could not detect label column; pass --label_col")
            label_col = min(cands, key=lambda c: df[c].nunique())
    return img_col, label_col


def seed_all(s=42):
    random.seed(s); np.random.seed(s); torch.manual_seed(s); torch.cuda.manual_seed_all(s)


# ----------------------------------------------------------------------------
# Train
# ----------------------------------------------------------------------------
def train(args):
    seed_all()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if device.type == "cuda":
        print(f"Using GPU: {torch.cuda.get_device_name(0)}")
        torch.backends.cudnn.benchmark = True
    else:
        print("[warn] CUDA not available - training on CPU.")

    by_name, by_stem = index_images(args.data)
    print(f"Found {len(by_name)} images")
    csv_path = args.csv or find_csv(args.data)
    df = pd.read_csv(csv_path)
    print(f"Metadata: {csv_path}  shape={df.shape}")
    img_col, label_col = detect_columns(df, by_name, by_stem, args.img_col, args.label_col)
    print(f"Image column: {img_col} | Label column: {label_col}")

    df["_path"] = df[img_col].astype(str).map(lambda v: resolve(v, by_name, by_stem))
    df = df.dropna(subset=["_path", label_col]).reset_index(drop=True)

    if args.exclude_labels:
        df = df[~df[label_col].astype(str).isin(args.exclude_labels)]
    vc = df[label_col].astype(str).value_counts()
    rare = vc[vc < args.min_class_count]
    if len(rare):
        print(f"Dropping rare classes (<{args.min_class_count} samples): {rare.to_dict()}")
        df = df[~df[label_col].astype(str).isin(rare.index)]
    df = df.reset_index(drop=True)

    classes = sorted(df[label_col].astype(str).unique().tolist())
    cls2idx = {c: i for i, c in enumerate(classes)}
    y = df[label_col].astype(str).map(cls2idx).values
    print(f"Classes ({len(classes)}): {classes}")
    print(df[label_col].value_counts())

    idx = np.arange(len(df))
    try:
        tr, va = train_test_split(idx, test_size=0.2, stratify=y, random_state=42)
    except ValueError:
        tr, va = train_test_split(idx, test_size=0.2, random_state=42)
    paths = df["_path"].values

    tr_dl = DataLoader(SkinDataset(paths[tr], y[tr], get_transforms(args.img_size, True)), args.batch,
                       shuffle=True, num_workers=args.workers, pin_memory=True, drop_last=True,
                       persistent_workers=args.workers > 0)
    va_dl = DataLoader(SkinDataset(paths[va], y[va], get_transforms(args.img_size, False)), args.batch,
                       shuffle=False, num_workers=args.workers, pin_memory=True,
                       persistent_workers=args.workers > 0)

    model = build_cnn(args.backbone, len(classes)).to(device)

    counts = np.bincount(y[tr], minlength=len(classes)).astype(np.float32)
    w_np = np.sqrt(counts.sum() / (len(classes) * np.maximum(counts, 1)))
    w_np = np.clip(w_np / w_np.min(), 1.0, 10.0)
    w = torch.tensor(w_np / w_np.mean(), dtype=torch.float32, device=device)
    print("Class weights:", dict(zip(classes, np.round(w.cpu().numpy(), 2))))
    crit = nn.CrossEntropyLoss(weight=w, label_smoothing=0.05)

    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=args.lr, total_steps=args.epochs * len(tr_dl))
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")

    best_f1, bad = 0.0, 0
    for ep in range(1, args.epochs + 1):
        model.train()
        tot, n = 0.0, 0
        for img, lab in tqdm(tr_dl, desc=f"Epoch {ep}", leave=False):
            img, lab = img.to(device, non_blocking=True), lab.to(device)
            opt.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type, enabled=device.type == "cuda"):
                loss = crit(model(img), lab)
            scaler.scale(loss).backward()
            scaler.unscale_(opt)
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            scaler.step(opt)
            scaler.update()
            sched.step()
            tot += loss.item() * img.size(0)
            n += img.size(0)

        model.eval()
        preds, gts = [], []
        with torch.no_grad(), torch.autocast(device_type=device.type, enabled=device.type == "cuda"):
            for img, lab in va_dl:
                preds.append(model(img.to(device)).argmax(1).cpu()); gts.append(lab)
        preds, gts = torch.cat(preds).numpy(), torch.cat(gts).numpy()
        acc = (preds == gts).mean()
        f1 = f1_score(gts, preds, average="macro")
        print(f"Epoch {ep:02d}/{args.epochs} | loss {tot/n:.4f} | val acc {acc:.4f} | macro-F1 {f1:.4f}")

        if f1 > best_f1:
            best_f1, bad = f1, 0
            torch.save({"state": model.state_dict(), "classes": classes, "backbone": args.backbone,
                        "img_size": args.img_size, "img_col": img_col, "label_col": label_col}, args.out)
            print(f"  saved best -> {args.out}")
        else:
            bad += 1
            if bad >= args.patience:
                print("Early stopping.")
                break

    model, _ = load_checkpoint(args.out, device)
    preds, gts = [], []
    with torch.no_grad():
        for img, lab in va_dl:
            preds.append(model(img.to(device)).argmax(1).cpu()); gts.append(lab)
    print(classification_report(torch.cat(gts).numpy(), torch.cat(preds).numpy(),
                                labels=list(range(len(classes))), target_names=classes, zero_division=0))
    with open(os.path.splitext(args.out)[0] + "_classes.json", "w") as f:
        json.dump({"classes": classes}, f, indent=2)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=r"C:\Users\moham\Downloads\archive (3)")
    ap.add_argument("--csv", default=None)
    ap.add_argument("--img_col", default=None)
    ap.add_argument("--label_col", default=None)
    ap.add_argument("--exclude_labels", nargs="*", default=[])
    ap.add_argument("--min_class_count", type=int, default=50)
    ap.add_argument("--backbone", default="efficientnet_b0",
                    choices=["efficientnet_b0", "resnet50", "densenet121", "simple_cnn"])
    ap.add_argument("--img_size", type=int, default=224)
    ap.add_argument("--epochs", type=int, default=25)
    ap.add_argument("--batch", type=int, default=32)
    ap.add_argument("--lr", type=float, default=3e-4)
    ap.add_argument("--workers", type=int, default=0 if os.name == "nt" else 4)
    ap.add_argument("--patience", type=int, default=6)
    ap.add_argument("--out", default="cnn_model.pt")
    train(ap.parse_args())
