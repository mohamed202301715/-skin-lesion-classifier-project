
import os

import numpy as np
import pandas as pd
import torch

from PIL import Image
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import StratifiedGroupKFold

from preprocessing import (
    get_image_transforms,
    build_clinical_preprocessor
)


# ==========================================
# 1. CONFIGURATION
# ==========================================

CLINICAL_COLUMNS = [
    "age_approx",
    "sex",
    "anatom_site_general_challenge"
]


# ==========================================
# 2. DATASET
# ==========================================

class SkinLesionDataset(Dataset):

    def __init__(
        self,
        dataframe,
        image_dir,
        clinical_features,
        transform=None
    ):

        self.dataframe = dataframe.reset_index(drop=True).copy()
        self.image_dir = image_dir
        self.clinical_features = np.asarray(
            clinical_features,
            dtype=np.float32
        )
        self.transform = transform

        if len(self.dataframe) != len(self.clinical_features):
            raise ValueError(
                "Dataframe and clinical features have different lengths."
            )

    def __len__(self):
        return len(self.dataframe)

    def __getitem__(self, index):

        row = self.dataframe.iloc[index]

        image_name = str(row["image_name"])

        if not image_name.lower().endswith(
            (".jpg", ".jpeg", ".png")
        ):
            image_name += ".jpg"

        image_path = os.path.join(
            self.image_dir,
            image_name
        )

        with Image.open(image_path) as image:
            image = image.convert("RGB")

            if self.transform is not None:
                image = self.transform(image)

        clinical = torch.tensor(
            self.clinical_features[index],
            dtype=torch.float32
        )

        label = torch.tensor(
            float(row["target"]),
            dtype=torch.float32
        )

        return image, clinical, label


# ==========================================
# 3. PREPARE DATASETS
# ==========================================

def prepare_datasets(
    base_dir="Data/skin_lesion",
    batch_size=4,
    num_workers=0
):

    train_csv_path = os.path.join(
        base_dir,
        "train.csv"
    )

    train_image_dir = os.path.join(
        base_dir,
        "train"
    )

    # --------------------------------------
    # Load CSV
    # --------------------------------------

    if not os.path.exists(train_csv_path):
        raise FileNotFoundError(
            f"Training CSV not found: {train_csv_path}"
        )

    if not os.path.isdir(train_image_dir):
        raise FileNotFoundError(
            f"Training image directory not found: {train_image_dir}"
        )

    dataframe = pd.read_csv(train_csv_path)

    required_columns = [
        "image_name",
        "patient_id",
        "target",
        *CLINICAL_COLUMNS
    ]

    missing_columns = [
        column
        for column in required_columns
        if column not in dataframe.columns
    ]

    if missing_columns:
        raise ValueError(
            f"Missing required columns: {missing_columns}"
        )

    dataframe["target"] = dataframe["target"].astype(int)

    # --------------------------------------
    # Group-aware stratified split
    # --------------------------------------

    splitter = StratifiedGroupKFold(
        n_splits=5,
        shuffle=True,
        random_state=42
    )

    train_indices, val_indices = next(
        splitter.split(
            X=dataframe,
            y=dataframe["target"],
            groups=dataframe["patient_id"]
        )
    )

    train_df = dataframe.iloc[train_indices].copy()
    val_df = dataframe.iloc[val_indices].copy()

    train_df.reset_index(drop=True, inplace=True)
    val_df.reset_index(drop=True, inplace=True)

    # --------------------------------------
    # Check patient leakage
    # --------------------------------------

    train_patients = set(
        train_df["patient_id"].dropna().unique()
    )

    val_patients = set(
        val_df["patient_id"].dropna().unique()
    )

    patient_overlap = train_patients.intersection(
        val_patients
    )

    if len(patient_overlap) > 0:
        raise RuntimeError(
            f"Patient leakage detected: {len(patient_overlap)} patients."
        )

    # --------------------------------------
    # Clinical preprocessing
    # Fit ONLY on training data
    # --------------------------------------

    preprocessor = build_clinical_preprocessor()

    train_clinical = preprocessor.fit_transform(
        train_df[CLINICAL_COLUMNS]
    )

    val_clinical = preprocessor.transform(
        val_df[CLINICAL_COLUMNS]
    )

    train_clinical = np.asarray(
        train_clinical,
        dtype=np.float32
    )

    val_clinical = np.asarray(
        val_clinical,
        dtype=np.float32
    )

    # --------------------------------------
    # Image transformations
    # --------------------------------------

    train_transform = get_image_transforms(
        training=True
    )

    val_transform = get_image_transforms(
        training=False
    )

    # --------------------------------------
    # Create datasets
    # --------------------------------------

    train_dataset = SkinLesionDataset(
        dataframe=train_df,
        image_dir=train_image_dir,
        clinical_features=train_clinical,
        transform=train_transform
    )

    val_dataset = SkinLesionDataset(
        dataframe=val_df,
        image_dir=train_image_dir,
        clinical_features=val_clinical,
        transform=val_transform
    )

    # --------------------------------------
    # Normal DataLoaders
    # NO WeightedRandomSampler
    # --------------------------------------

    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=torch.cuda.is_available()
    )

    val_loader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=torch.cuda.is_available()
    )

    # --------------------------------------
    # Dataset information
    # --------------------------------------

    train_counts = train_df["target"].value_counts().sort_index()
    val_counts = val_df["target"].value_counts().sort_index()

    print("\nDATASET PREPARATION COMPLETED")
    print("=" * 45)

    print("Training images:", len(train_dataset))
    print("Validation images:", len(val_dataset))

    print("Training patients:", len(train_patients))
    print("Validation patients:", len(val_patients))

    print(
        "Clinical features:",
        train_clinical.shape[1]
    )

    print("\nTraining labels:")
    print(train_counts)

    print("\nValidation labels:")
    print(val_counts)

    print("\nPatient leakage:", len(patient_overlap))

    return train_loader, val_loader, preprocessor
