
import numpy as np
import torch

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    average_precision_score,
    confusion_matrix
)


def evaluate_model(model, loader, criterion, device):

    model.eval()

    total_loss = 0.0

    all_labels = []
    all_probabilities = []

    with torch.inference_mode():

        for images, clinical, labels in loader:

            images = images.to(device, non_blocking=True)
            clinical = clinical.to(device, non_blocking=True)
            labels = labels.to(device, non_blocking=True)

            with torch.autocast(
                device_type="cuda",
                dtype=torch.float16,
                enabled=(device.type == "cuda")
            ):

                logits = model(images, clinical)
                loss = criterion(logits, labels)

            probabilities = torch.sigmoid(logits.float())

            total_loss += loss.item() * labels.size(0)

            all_labels.extend(labels.cpu().numpy())
            all_probabilities.extend(probabilities.cpu().numpy())

    y_true = np.asarray(all_labels).astype(int)
    y_prob = np.asarray(all_probabilities)

    # Default threshold
    y_pred = (y_prob >= 0.5).astype(int)

    metrics = {
        "loss": total_loss / len(loader.dataset),
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(
            y_true, y_pred, zero_division=0
        ),
        "recall": recall_score(
            y_true, y_pred, zero_division=0
        ),
        "f1": f1_score(
            y_true, y_pred, zero_division=0
        ),
        "pr_auc": average_precision_score(y_true, y_prob),
        "roc_auc": roc_auc_score(y_true, y_prob),
        "confusion_matrix": confusion_matrix(
            y_true, y_pred
        )
    }

    return metrics
