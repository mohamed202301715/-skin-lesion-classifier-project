
import torch
import torch.nn as nn
import timm


class MultimodalSkinLesionModel(nn.Module):

    def __init__(
        self,
        clinical_input_dim=9,
        pretrained=True,
        dropout=0.3
    ):

        super().__init__()

        # =================================
        # 1. Image Branch: Vision Transformer
        # =================================

        self.image_encoder = timm.create_model(
            "deit_tiny_patch16_224",
            pretrained=pretrained,
            num_classes=0
        )

        image_feature_dim = self.image_encoder.num_features

        # =================================
        # 2. Clinical Branch
        # =================================

        self.clinical_encoder = nn.Sequential(

            nn.Linear(clinical_input_dim, 64),

            nn.BatchNorm1d(64),

            nn.ReLU(),

            nn.Dropout(dropout),

            nn.Linear(64, 32),

            nn.ReLU()
        )

        clinical_feature_dim = 32

        # =================================
        # 3. Feature Fusion
        # =================================

        fusion_input_dim = (
            image_feature_dim + clinical_feature_dim
        )

        self.classifier = nn.Sequential(

            nn.Linear(fusion_input_dim, 128),

            nn.BatchNorm1d(128),

            nn.ReLU(),

            nn.Dropout(dropout),

            nn.Linear(128, 64),

            nn.ReLU(),

            nn.Dropout(dropout),

            nn.Linear(64, 1)
        )

    def forward(self, images, clinical):

        # Extract image features
        image_features = self.image_encoder(images)

        # Extract clinical features
        clinical_features = self.clinical_encoder(clinical)

        # Combine both branches
        combined_features = torch.cat(
            [image_features, clinical_features],
            dim=1
        )

        # Binary classification logits
        logits = self.classifier(combined_features)

        return logits.squeeze(1)
