"""
Streamlit app for the multimodal skin lesion fusion network.
Run:  streamlit run app.py
"""
import glob
import io
import numpy as np
import pandas as pd
import streamlit as st
import torch
from PIL import Image, ImageOps

from model import load_checkpoint, get_transforms, encode_tabular

st.set_page_config(page_title="Skin Lesion Multimodal Classifier", page_icon="🩺", layout="wide")


@st.cache_resource(show_spinner="Loading model...")
def get_model(path, dev):
    return load_checkpoint(path, torch.device(dev))


# ------------------------------------------------------------------ Sidebar
with st.sidebar:
    st.header("⚙️ Settings")

    st.subheader("Model")
    found = sorted(glob.glob("*.pt") + glob.glob("*.pth"))
    if found:
        ckpt_path = st.selectbox("Checkpoint", found)
    else:
        ckpt_path = st.text_input("Checkpoint path", "fusion_model.pt")

    dev_opts = ["cuda", "cpu"] if torch.cuda.is_available() else ["cpu"]
    dev_name = st.radio("Device", dev_opts, horizontal=True)
    if dev_name == "cuda":
        st.success(f"GPU: {torch.cuda.get_device_name(0)}")
    elif torch.cuda.is_available() is False:
        st.warning("CUDA not available — running on CPU")
    use_amp = st.checkbox("Mixed precision (faster on GPU)", value=dev_name == "cuda", disabled=dev_name == "cpu")

    st.subheader("Input")
    input_mode = st.radio("Image source", ["Upload", "Camera"], horizontal=True)
    mode = st.radio("Prediction mode", ["Fusion (image + clinical)", "Image only"])
    auto_orient = st.checkbox("Auto-fix image orientation (EXIF)", value=True)
    img_width = st.slider("Preview width (px)", 150, 600, 350, 25)

    st.subheader("Prediction")
    top_k = st.slider("Top-K classes to show", 1, 10, 5)
    threshold = st.slider("Low-confidence warning below (%)", 0, 100, 50, 5)
    tta = st.selectbox("Test-time augmentation", ["Off", "Flips (4 views)", "Flips + rotations (8 views)"])
    chart_type = st.selectbox("Chart type", ["Bar chart", "Table only"])
    show_all = st.checkbox("Show all classes in table", value=False)

device = torch.device(dev_name)

# ------------------------------------------------------------------ Model
st.title("🩺 Multimodal Skin Lesion Classification")
st.caption("Image + clinical metadata fusion network")

try:
    model, ck = get_model(ckpt_path, dev_name)
except Exception as e:
    st.error(f"Could not load checkpoint '{ckpt_path}'. Train first with `python model.py`.\n\n{e}")
    st.stop()

meta, classes = ck["meta"], ck["classes"]
use_tab = mode.startswith("Fusion") and ck["tab_dim"] > 0
if mode.startswith("Fusion") and ck["tab_dim"] == 0:
    st.sidebar.info("This checkpoint has no clinical features; using image only.")

col_in, col_out = st.columns(2)

# ------------------------------------------------------------------ Inputs
with col_in:
    st.subheader("1. Lesion image")
    if input_mode == "Upload":
        up = st.file_uploader("Upload image", type=["jpg", "jpeg", "png", "bmp", "webp"])
    else:
        up = st.camera_input("Take a photo")

    image = None
    if up:
        image = Image.open(up)
        if auto_orient:
            image = ImageOps.exif_transpose(image)
        image = image.convert("RGB")
        st.image(image, width=img_width, caption=f"{image.width}×{image.height}")

    row = {}
    if use_tab:
        st.subheader("2. Clinical information")
        cols = st.columns(2)
        i = 0
        for c, (m, s) in meta["num"].items():
            with cols[i % 2]:
                row[c] = st.number_input(c, value=float(round(m, 2)))
            i += 1
        for c, vals in meta["cat"].items():
            with cols[i % 2]:
                row[c] = st.selectbox(c, vals + ["unknown"])
            i += 1


# ------------------------------------------------------------------ Predict
def predict(img):
    base = get_transforms(ck["img_size"])
    views = [img]
    if tta != "Off":
        views += [ImageOps.mirror(img), ImageOps.flip(img), ImageOps.flip(ImageOps.mirror(img))]
    if tta.startswith("Flips +"):
        views += [img.rotate(90), img.rotate(180), img.rotate(270), ImageOps.mirror(img.rotate(90))]
    x = torch.stack([base(v) for v in views]).to(device)
    t = None
    if use_tab:
        t = torch.from_numpy(encode_tabular(row, meta)).unsqueeze(0).repeat(len(views), 1).to(device)
    with torch.no_grad(), torch.autocast(device_type=device.type, enabled=use_amp and device.type == "cuda"):
        out = model(x, t)
    return torch.softmax(out.float(), dim=1).mean(0).cpu().numpy()


with col_out:
    st.subheader("3. Prediction")
    if st.button("Predict", type="primary", disabled=image is None):
        probs = predict(image)
        order = np.argsort(-probs)
        best = order[0]
        st.metric("Predicted class", classes[best], f"{probs[best] * 100:.1f}% confidence")
        if probs[best] * 100 < threshold:
            st.warning(f"Confidence is below {threshold}% — treat this result as uncertain.")

        shown = order if show_all else order[:top_k]
        df = pd.DataFrame({"class": [classes[k] for k in shown], "probability": probs[shown]}).set_index("class")
        if chart_type == "Bar chart":
            st.bar_chart(df)
        st.dataframe(df.style.format("{:.2%}"), use_container_width=True)

        full = pd.DataFrame({"class": classes, "probability": probs}).sort_values("probability", ascending=False)
        st.download_button("⬇️ Download results (CSV)", full.to_csv(index=False).encode(),
                           "prediction.csv", "text/csv")
        st.info("Research/educational tool only — not a medical diagnosis.")
