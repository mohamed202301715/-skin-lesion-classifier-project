
import os
import random
import copy

import numpy as np
import torch
import joblib

from torch.optim import AdamW
from torch.optim.lr_scheduler import ReduceLROnPlateau

from data_loader import prepare_datasets
from model import MultimodalSkinLesionModel
from loss import get_weighted_loss, get_focal_loss
from evaluate import evaluate_model


# ==========================================
# 1. CONFIGURATION
# ==========================================

SEED = 42

BATCH_SIZE = 4
NUM_WORKERS = 0

PHASE1_EPOCHS = 5
PHASE2_EPOCHS = 5

LEARNING_RATE_HEAD = 1e-4
LEARNING_RATE_VIT = 1e-5

WEIGHT_DECAY = 1e-4
PATIENCE = 3

DEVICE = torch.device(
    "cuda" if torch.cuda.is_available() else "cpu"
)

OUTPUT_DIR = "outputs"
CHECKPOINT_DIR = os.path.join(
    OUTPUT_DIR,
    "checkpoints"
)

os.makedirs(CHECKPOINT_DIR, exist_ok=True)

# Original Focal checkpoints
PHASE1_PATH = os.path.join(
    CHECKPOINT_DIR,
    "focal_phase1_best_model.pth"
)

PHASE2_PATH = os.path.join(
    CHECKPOINT_DIR,
    "focal_phase2_best_model.pth"
)

FINAL_PATH = os.path.join(
    CHECKPOINT_DIR,
    "focal_final_best_model.pth"
)

PREPROCESSOR_PATH = os.path.join(
    OUTPUT_DIR,
    "clinical_preprocessor.pkl"
)


# ==========================================
# LOSS EXPERIMENT CONFIGURATION
# ==========================================

LOSS_TYPE = "focal"

FOCAL_GAMMA = 2.0


# ==========================================
# 2. REPRODUCIBILITY
# ==========================================

def set_seed(seed=42):

    random.seed(seed)
    np.random.seed(seed)

    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


# ==========================================
# 3. FREEZE / UNFREEZE ViT
# ==========================================

def freeze_vit(model):

    for param in model.image_encoder.parameters():
        param.requires_grad = False

    print("\nViT encoder is frozen.")


def unfreeze_last_blocks(model, number_of_blocks=2):

    for param in model.image_encoder.parameters():
        param.requires_grad = False

    blocks = model.image_encoder.blocks

    for block in blocks[-number_of_blocks:]:

        for param in block.parameters():
            param.requires_grad = True

    if hasattr(model.image_encoder, "norm"):

        for param in model.image_encoder.norm.parameters():
            param.requires_grad = True

    print(
        f"\nLast {number_of_blocks} ViT blocks are unfrozen."
    )


# ==========================================
# 4. TRAIN ONE EPOCH
# ==========================================

def train_one_epoch(
    model,
    loader,
    criterion,
    optimizer,
    scaler,
    device,
    frozen_vit=False
):

    model.train()

    if frozen_vit:
        model.image_encoder.eval()

    total_loss = 0.0

    for batch_idx, (images, clinical, labels) in enumerate(loader):

        images = images.to(device, non_blocking=True)
        clinical = clinical.to(device, non_blocking=True)
        labels = labels.to(device, non_blocking=True)

        optimizer.zero_grad(set_to_none=True)

        with torch.autocast(
            device_type=device.type,
            dtype=torch.float16,
            enabled=(device.type == "cuda")
        ):

            logits = model(images, clinical)
            loss = criterion(logits, labels)

        scaler.scale(loss).backward()

        scaler.unscale_(optimizer)

        torch.nn.utils.clip_grad_norm_(
            model.parameters(),
            max_norm=1.0
        )

        scaler.step(optimizer)
        scaler.update()

        total_loss += loss.item() * images.size(0)

        if (batch_idx + 1) % 500 == 0:

            print(
                f"Batch [{batch_idx + 1}/{len(loader)}] "
                f"Loss: {loss.item():.4f}"
            )

    return total_loss / len(loader.dataset)


# ==========================================
# 5. CREATE OPTIMIZER
# ==========================================

def create_optimizer(model, frozen_vit):

    if frozen_vit:

        trainable_params = filter(
            lambda p: p.requires_grad,
            model.parameters()
        )

        optimizer = AdamW(
            trainable_params,
            lr=LEARNING_RATE_HEAD,
            weight_decay=WEIGHT_DECAY
        )

    else:

        image_params = [
            p for p in model.image_encoder.parameters()
            if p.requires_grad
        ]

        head_params = [
            p for name, p in model.named_parameters()
            if p.requires_grad
            and not name.startswith("image_encoder.")
        ]

        optimizer = AdamW(
            [
                {
                    "params": image_params,
                    "lr": LEARNING_RATE_VIT
                },
                {
                    "params": head_params,
                    "lr": LEARNING_RATE_HEAD
                }
            ],
            weight_decay=WEIGHT_DECAY
        )

    return optimizer


# ==========================================
# 6. TRAINING PHASE
# ==========================================

def run_phase(
    model,
    train_loader,
    val_loader,
    criterion,
    device,
    epochs,
    phase_name,
    frozen_vit,
    checkpoint_path
):

    optimizer = create_optimizer(model, frozen_vit)

    scheduler = ReduceLROnPlateau(
        optimizer,
        mode="max",
        factor=0.5,
        patience=1,
        min_lr=1e-7
    )

    scaler = torch.amp.GradScaler(
        "cuda",
        enabled=(device.type == "cuda")
    )

    best_pr_auc = -1.0
    best_epoch = 0
    best_metrics = None

    epochs_without_improvement = 0

    print("\n" + "=" * 55)
    print(f"STARTING {phase_name}")
    print("=" * 55)

    for epoch in range(epochs):

        print(
            f"\n{phase_name} | Epoch {epoch + 1}/{epochs}"
        )

        # Training
        train_loss = train_one_epoch(
            model=model,
            loader=train_loader,
            criterion=criterion,
            optimizer=optimizer,
            scaler=scaler,
            device=device,
            frozen_vit=frozen_vit
        )

        # Validation
        val_metrics = evaluate_model(
            model=model,
            loader=val_loader,
            criterion=criterion,
            device=device
        )

        val_pr_auc = val_metrics["pr_auc"]

        scheduler.step(val_pr_auc)

        # Print results
        print("\nTraining Results")
        print("-" * 40)

        print(f"Train Loss: {train_loss:.4f}")
        print(f"Validation Loss: {val_metrics['loss']:.4f}")

        print(f"Accuracy: {val_metrics['accuracy']:.4f}")
        print(f"Precision: {val_metrics['precision']:.4f}")
        print(f"Recall: {val_metrics['recall']:.4f}")
        print(f"F1 Score: {val_metrics['f1']:.4f}")

        print(f"ROC-AUC: {val_metrics['roc_auc']:.4f}")
        print(f"PR-AUC: {val_pr_auc:.4f}")

        print("\nConfusion Matrix:")
        print(val_metrics["confusion_matrix"])

        # Save best checkpoint for this phase
        if val_pr_auc > best_pr_auc:

            best_pr_auc = val_pr_auc
            best_epoch = epoch + 1
            best_metrics = copy.deepcopy(val_metrics)

            epochs_without_improvement = 0

            torch.save(
                {
                    "model_state_dict": model.state_dict(),
                    "best_pr_auc": best_pr_auc,
                    "phase": phase_name,
                    "epoch": best_epoch,
                    "metrics": best_metrics
                },
                checkpoint_path
            )

            print(
                f"\nBest checkpoint saved: {checkpoint_path}"
            )

        else:

            epochs_without_improvement += 1

            print(
                f"\nNo improvement: "
                f"{epochs_without_improvement}/{PATIENCE}"
            )

        # Early stopping
        if epochs_without_improvement >= PATIENCE:

            print("\nEarly stopping triggered.")
            break

        # GPU monitoring
        if device.type == "cuda":

            allocated = (
                torch.cuda.memory_allocated(device) / (1024 ** 3)
            )

            reserved = (
                torch.cuda.memory_reserved(device) / (1024 ** 3)
            )

            print(f"\nGPU Memory Allocated: {allocated:.2f} GB")
            print(f"GPU Memory Reserved: {reserved:.2f} GB")

    print(f"\n{phase_name} completed.")

    if best_metrics is None:
        raise RuntimeError(
            f"No valid checkpoint was saved for {phase_name}"
        )

    return {
        "path": checkpoint_path,
        "best_pr_auc": best_pr_auc,
        "best_epoch": best_epoch,
        "phase": phase_name,
        "metrics": best_metrics
    }


# ==========================================
# 7. LOAD CHECKPOINT
# ==========================================

def load_checkpoint(path):

    return torch.load(
        path,
        map_location="cpu",
        weights_only=False
    )


# ==========================================
# 8. MAIN TRAINING PIPELINE
# ==========================================

def main():

    set_seed(SEED)

    print("\nDEVICE:", DEVICE)

    if DEVICE.type == "cuda":

        print(
            "GPU:",
            torch.cuda.get_device_name(0)
        )

    print("\nEXPERIMENT: ORIGINAL FOCAL TRAINING")
    print("Sampling: Normal shuffle")
    print("Loss:", LOSS_TYPE)
    print("Focal gamma:", FOCAL_GAMMA)
    print("Patient split: StratifiedGroupKFold")

    # --------------------------------------
    # Prepare datasets
    # --------------------------------------

    print("\nPreparing datasets...")

    train_loader, val_loader, preprocessor = prepare_datasets(
        base_dir="Data/skin_lesion",
        batch_size=BATCH_SIZE,
        num_workers=NUM_WORKERS
    )

    # Save original preprocessor
    joblib.dump(
        preprocessor,
        PREPROCESSOR_PATH
    )

    print(
        "\nClinical preprocessor saved:",
        PREPROCESSOR_PATH
    )

    # --------------------------------------
    # Calculate loss
    # --------------------------------------

    print("\nPreparing loss function...")

    if LOSS_TYPE == "focal":

        criterion = get_focal_loss(
            train_loader.dataset,
            DEVICE,
            gamma=FOCAL_GAMMA
        )

    elif LOSS_TYPE == "weighted_bce":

        criterion = get_weighted_loss(
            train_loader.dataset,
            DEVICE
        )

    else:

        raise ValueError(
            f"Unknown loss type: {LOSS_TYPE}"
        )

    criterion = criterion.to(DEVICE)

    # --------------------------------------
    # Clinical input size
    # --------------------------------------

    _, sample_clinical, _ = next(iter(train_loader))

    clinical_input_dim = sample_clinical.shape[1]

    print(
        "\nClinical input dimension:",
        clinical_input_dim
    )

    # --------------------------------------
    # Initialize model
    # --------------------------------------

    print("\nInitializing DeiT Tiny model...")

    model = MultimodalSkinLesionModel(
        clinical_input_dim=clinical_input_dim,
        pretrained=True,
        dropout=0.3
    ).to(DEVICE)

    total_params = sum(
        p.numel() for p in model.parameters()
    )

    print(f"Total parameters: {total_params:,}")

    # ======================================
    # PHASE 1
    # ======================================

    freeze_vit(model)

    phase1_result = run_phase(
        model=model,
        train_loader=train_loader,
        val_loader=val_loader,
        criterion=criterion,
        device=DEVICE,
        epochs=PHASE1_EPOCHS,
        phase_name="PHASE 1 - FROZEN ViT",
        frozen_vit=True,
        checkpoint_path=PHASE1_PATH
    )

    # Load best Phase 1 weights before Phase 2
    phase1_checkpoint = load_checkpoint(PHASE1_PATH)

    model.load_state_dict(
        phase1_checkpoint["model_state_dict"]
    )

    model.to(DEVICE)

    print(
        "\nLoaded best Phase 1 checkpoint:",
        phase1_result["best_pr_auc"]
    )

    # ======================================
    # PHASE 2
    # ======================================

    unfreeze_last_blocks(
        model,
        number_of_blocks=2
    )

    phase2_result = run_phase(
        model=model,
        train_loader=train_loader,
        val_loader=val_loader,
        criterion=criterion,
        device=DEVICE,
        epochs=PHASE2_EPOCHS,
        phase_name="PHASE 2 - FINE TUNING",
        frozen_vit=False,
        checkpoint_path=PHASE2_PATH
    )

    # ======================================
    # COMPARE BOTH PHASES
    # ======================================

    print("\n" + "=" * 55)
    print("PHASE COMPARISON")
    print("=" * 55)

    print(
        f"Phase 1 PR-AUC: {phase1_result['best_pr_auc']:.6f}"
    )

    print(
        f"Phase 2 PR-AUC: {phase2_result['best_pr_auc']:.6f}"
    )

    if (
        phase1_result["best_pr_auc"]
        >= phase2_result["best_pr_auc"]
    ):

        best_result = phase1_result

    else:

        best_result = phase2_result

    # ======================================
    # SAVE GLOBAL BEST MODEL
    # ======================================

    best_checkpoint = load_checkpoint(
        best_result["path"]
    )

    torch.save(
        {
            "model_state_dict": best_checkpoint["model_state_dict"],
            "best_pr_auc": best_result["best_pr_auc"],
            "phase": best_result["phase"],
            "epoch": best_result["best_epoch"],
            "metrics": best_result["metrics"]
        },
        FINAL_PATH
    )

    # ======================================
    # FINAL REPORT
    # ======================================

    print("\n" + "=" * 55)
    print("TRAINING COMPLETED SUCCESSFULLY!")
    print("=" * 55)

    print(
        f"Phase 1 Best PR-AUC: "
        f"{phase1_result['best_pr_auc']:.6f}"
    )

    print(
        f"Phase 2 Best PR-AUC: "
        f"{phase2_result['best_pr_auc']:.6f}"
    )

    print("\nGLOBAL BEST MODEL")

    print("Best PR-AUC:", best_result["best_pr_auc"])
    print("Best phase:", best_result["phase"])
    print("Best epoch:", best_result["best_epoch"])

    print("\nSaved checkpoints:")
    print("Phase 1:", PHASE1_PATH)
    print("Phase 2:", PHASE2_PATH)
    print("Final:", FINAL_PATH)

    print("\nPreprocessor:", PREPROCESSOR_PATH)


# ==========================================
# 9. RUN
# ==========================================

if __name__ == "__main__":
    main()
