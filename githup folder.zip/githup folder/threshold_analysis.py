
import os

# ======================================
# LIMIT CPU THREADS
# ======================================

os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"

import numpy as np
import pandas as pd
import torch

torch.set_num_threads(1)
torch.set_num_interop_threads(1)

import matplotlib
matplotlib.use("Agg")

import matplotlib.pyplot as plt

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    average_precision_score,
    roc_auc_score,
    precision_recall_curve
)

from data_loader import prepare_datasets
from model import MultimodalSkinLesionModel


# ======================================
# CONFIGURATION
# ======================================

DEVICE = torch.device("cpu")

CHECKPOINT_PATH = "outputs/checkpoints/focal_final_best_model.pth"

BATCH_SIZE = 1

OUTPUT_DIR = "outputs"

PRECISION_TARGETS = [0.20, 0.30]


# ======================================
# LOAD VALIDATION DATA
# ======================================

def load_validation_data():

    _, val_loader, _ = prepare_datasets(
        base_dir="Data/skin_lesion",
        batch_size=BATCH_SIZE,
        num_workers=0
    )

    return val_loader


# ======================================
# LOAD MODEL
# ======================================

def load_model(clinical_input_dim=9):

    model = MultimodalSkinLesionModel(
        clinical_input_dim=clinical_input_dim,
        pretrained=False
    )

    checkpoint = torch.load(
        CHECKPOINT_PATH,
        map_location="cpu",
        weights_only=False
    )

    model.load_state_dict(
        checkpoint["model_state_dict"]
    )

    model = model.to(DEVICE)
    model.eval()

    print("\nModel loaded successfully!")
    print("Checkpoint phase:", checkpoint["phase"])
    print("Checkpoint epoch:", checkpoint["epoch"])
    print("Checkpoint PR-AUC:", checkpoint["best_pr_auc"])

    return model


# ======================================
# GET PREDICTIONS
# ======================================

def get_predictions(model, loader):

    all_labels = []
    all_probabilities = []

    model.eval()

    with torch.inference_mode():

        for images, clinical, labels in loader:

            images = images.to(DEVICE)
            clinical = clinical.to(DEVICE)

            logits = model(images, clinical)

            probabilities = torch.sigmoid(
                logits.float()
            )

            all_labels.extend(labels.numpy())

            all_probabilities.extend(
                probabilities.cpu().numpy()
            )

    return (
        np.asarray(all_labels).astype(int),
        np.asarray(all_probabilities).reshape(-1)
    )


# ======================================
# EVALUATE ONE THRESHOLD
# ======================================

def evaluate_threshold(y_true, y_prob, threshold):

    y_pred = (y_prob >= threshold).astype(int)

    precision = precision_score(
        y_true,
        y_pred,
        zero_division=0
    )

    recall = recall_score(
        y_true,
        y_pred,
        zero_division=0
    )

    f1 = f1_score(
        y_true,
        y_pred,
        zero_division=0
    )

    accuracy = accuracy_score(
        y_true,
        y_pred
    )

    tn, fp, fn, tp = confusion_matrix(
        y_true,
        y_pred,
        labels=[0, 1]
    ).ravel()

    return {
        "Threshold": float(threshold),
        "Accuracy": accuracy,
        "Precision": precision,
        "Recall": recall,
        "F1": f1,
        "TP": int(tp),
        "FP": int(fp),
        "TN": int(tn),
        "FN": int(fn)
    }


# ======================================
# PRINT CONFUSION MATRIX
# ======================================

def print_confusion_matrix(result, title):

    print("\n" + "=" * 60)
    print(title)
    print("=" * 60)

    print(f"Threshold : {result['Threshold']:.8f}")

    print("\nConfusion Matrix:")
    print("                 Predicted")
    print("              Benign  Malignant")

    print(
        f"Actual Benign  {result['TN']:6d}  {result['FP']:9d}"
    )

    print(
        f"Actual Malig.  {result['FN']:6d}  {result['TP']:9d}"
    )

    print("\nMetrics:")

    for metric in [
        "Accuracy",
        "Precision",
        "Recall",
        "F1"
    ]:

        print(
            f"{metric:12s}: {result[metric]:.4f}"
        )


# ======================================
# PLOT PRECISION-RECALL CURVE
# ======================================

def plot_pr_curve(
    y_true,
    y_prob,
    best_f1,
    best_recall_20,
    best_recall_30
):

    precision, recall, thresholds = precision_recall_curve(
        y_true,
        y_prob
    )

    plt.figure(figsize=(10, 7))

    plt.plot(
        recall,
        precision,
        label="Precision-Recall Curve",
        linewidth=2
    )

    # No-skill baseline = positive class prevalence
    baseline = np.mean(y_true)

    plt.axhline(
        y=baseline,
        linestyle="--",
        label=f"Baseline ({baseline:.4f})"
    )

    selected_results = [
        (best_f1, "Best F1"),
        (best_recall_20, "Best Recall (P >= 20%)"),
        (best_recall_30, "Best Recall (P >= 30%)")
    ]

    for result, label in selected_results:

        if result is not None:

            plt.scatter(
                result["Recall"],
                result["Precision"],
                s=90,
                label=label
            )

    plt.xlabel("Recall")
    plt.ylabel("Precision")

    plt.title("Precision-Recall Curve")

    plt.legend()
    plt.grid(alpha=0.3)

    plt.xlim(0, 1)
    plt.ylim(0, 1)

    plt.tight_layout()

    path = os.path.join(
        OUTPUT_DIR,
        "precision_recall_curve.png"
    )

    plt.savefig(
        path,
        dpi=300,
        bbox_inches="tight"
    )

    plt.close()

    print("\nPR Curve saved to:", path)


# ======================================
# THRESHOLD OPTIMIZATION
# ======================================

def analyze_thresholds(y_true, y_prob):

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    print("\nSTARTING THRESHOLD OPTIMIZATION")
    print("=" * 60)

    # Generate thresholds from actual model probabilities
    precision, recall, thresholds = precision_recall_curve(
        y_true,
        y_prob
    )

    # Last precision and recall values have no corresponding threshold
    precision = precision[:-1]
    recall = recall[:-1]

    # Calculate F1 for every threshold
    f1_values = (
        2 * precision * recall
        / (precision + recall + 1e-12)
    )

    # Calculate all threshold results
    results = []

    for threshold in thresholds:

        result = evaluate_threshold(
            y_true,
            y_prob,
            threshold
        )

        results.append(result)

    results_df = pd.DataFrame(results)

    results_df.to_csv(
        os.path.join(
            OUTPUT_DIR,
            "all_threshold_results.csv"
        ),
        index=False
    )

    # ----------------------------------
    # 1. BEST F1
    # ----------------------------------

    best_f1_index = int(np.argmax(f1_values))

    best_f1_threshold = thresholds[best_f1_index]

    best_f1_result = evaluate_threshold(
        y_true,
        y_prob,
        best_f1_threshold
    )

    print_confusion_matrix(
        best_f1_result,
        "BEST F1 THRESHOLD"
    )

    # ----------------------------------
    # 2. BEST RECALL WITH PRECISION >= 20%
    # ----------------------------------

    best_recall_results = {}

    for precision_target in PRECISION_TARGETS:

        valid_indices = np.where(
            precision >= precision_target
        )[0]

        if len(valid_indices) == 0:

            print(
                f"\nNo threshold achieved Precision >= "
                f"{precision_target:.0%}"
            )

            best_recall_results[precision_target] = None

            continue

        # Maximize recall among valid thresholds.
        # If recall ties, prefer higher precision.
        best_index = max(
            valid_indices,
            key=lambda i: (recall[i], precision[i])
        )

        best_threshold = thresholds[best_index]

        best_result = evaluate_threshold(
            y_true,
            y_prob,
            best_threshold
        )

        best_recall_results[precision_target] = best_result

        print_confusion_matrix(
            best_result,
            f"BEST RECALL WITH PRECISION >= {precision_target:.0%}"
        )

    # ----------------------------------
    # 3. SAVE SUMMARY
    # ----------------------------------

    summary = []

    summary.append({
        "Selection": "Best F1",
        **best_f1_result
    })

    for precision_target, result in best_recall_results.items():

        if result is not None:

            summary.append({
                "Selection": f"Best Recall Precision >= {precision_target:.0%}",
                **result
            })

    summary_df = pd.DataFrame(summary)

    summary_path = os.path.join(
        OUTPUT_DIR,
        "threshold_optimization_summary.csv"
    )

    summary_df.to_csv(
        summary_path,
        index=False
    )

    # ----------------------------------
    # 4. OVERALL METRICS
    # ----------------------------------

    roc_auc = roc_auc_score(
        y_true,
        y_prob
    )

    average_precision = average_precision_score(
        y_true,
        y_prob
    )

    print("\n" + "=" * 60)
    print("OVERALL MODEL PERFORMANCE")
    print("=" * 60)

    print(f"ROC-AUC: {roc_auc:.6f}")
    print(f"Average Precision: {average_precision:.6f}")

    print(
        f"Positive Class Prevalence: {np.mean(y_true):.4%}"
    )

    # ----------------------------------
    # 5. PLOT PR CURVE
    # ----------------------------------

    plot_pr_curve(
        y_true,
        y_prob,
        best_f1_result,
        best_recall_results[0.20],
        best_recall_results[0.30]
    )

    print("\n" + "=" * 60)
    print("FILES SAVED SUCCESSFULLY")
    print("=" * 60)

    print("1. outputs/all_threshold_results.csv")
    print("2. outputs/threshold_optimization_summary.csv")
    print("3. outputs/precision_recall_curve.png")


# ======================================
# MAIN
# ======================================

def main():

    print("Device:", DEVICE)

    val_loader = load_validation_data()

    clinical_dim = (
        val_loader.dataset.clinical_features.shape[1]
    )

    model = load_model(clinical_dim)

    y_true, y_prob = get_predictions(
        model,
        val_loader
    )

    print("\nTotal validation samples:", len(y_true))

    print(
        "Actual malignant cases:",
        int(y_true.sum())
    )

    print("\nProbability Statistics:")

    print("Minimum:", y_prob.min())
    print("Maximum:", y_prob.max())
    print("Mean:", y_prob.mean())
    print("Median:", np.median(y_prob))

    analyze_thresholds(
        y_true,
        y_prob
    )


if __name__ == "__main__":
    main()
